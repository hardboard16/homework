const stripe = Stripe('pk_test_51P92GV07Wrcw1Bv5ehc8YmZJoy8ArBFPcMiYFjqxD4Jht4jSAoImLBLYXrgW4mtVHxLUDFZvM6wzugM5K0DPWWdm00CmomElZr');
 const paymentButton = document.querySelector('#paymentButton');
 
 paymentButton.addEventListener('click', () => {
   stripe.redirectToCheckout({
     sessionId: sessionId
   })
 });